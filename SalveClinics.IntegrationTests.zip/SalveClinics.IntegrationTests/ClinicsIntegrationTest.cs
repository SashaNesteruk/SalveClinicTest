using AutoFixture;
using Newtonsoft.Json;
using SalveClinics.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Xunit;

namespace SalveClinics.IntegrationTests
{
    [Collection("Database collection")]
    public class ClinicsIntegrationTest
    {

        private readonly Fixture _fixture;
        private readonly HttpClient _client;

        public ClinicsIntegrationTest(TestFixture testFixture)
        {
            _client = testFixture.Client;
            _fixture = testFixture.Fixture;
        }

        [Fact]
        public async void ListClinicsReturnsResults()
        {
            // Arrange

            // Act
            var response = await _client.GetAsync("/clinics");

            // Assert
            var responseAsString = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<List<Clinic>>(responseAsString);

            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
        }

        [Fact]
        public async void GetClinicOnePatients_GivenValidId()
        {
            // Arrange

            // Act
            var response = await _client.GetAsync("ClinicPatients?clinicId=1");

            // Assert
            var responseAsString = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<List<Patient>>(responseAsString);

            Assert.NotNull(result);
            Assert.Equal(200, result.Count);
        }

        [Fact]
        public async void GetClinicOnePatients_GivenInValidId()
        {
            // Arrange

            // Act
            var response = await _client.GetAsync("ClinicPatients?clinicId=5");

            // Assert

            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }
    }
}
